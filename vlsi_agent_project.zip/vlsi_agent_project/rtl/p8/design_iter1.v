module fp16_multiplier(
  a,
  b,
  result
);

  input  [15:0] a;
  input  [15:0] b;
  output [15:0] result;
  reg    [15:0] result;

  parameter [15:0] FP16_QNAN = 16'h7E00;

  reg        sign_a;
  reg        sign_b;
  reg        sign_r;
  reg [4:0]  exp_a;
  reg [4:0]  exp_b;
  reg [9:0]  frac_a;
  reg [9:0]  frac_b;
  reg [10:0] mant_a;
  reg [10:0] mant_b;
  reg [21:0] prod;
  reg [10:0] mant_pre;
  reg [10:0] mant_round;
  reg [31:0] sub_pre;
  reg [31:0] sub_round;
  reg        guard_bit;
  reg        sticky_bit;
  reg        lsb_bit;

  integer ea_eff;
  integer eb_eff;
  integer exp_norm;
  integer shift_amt;
  integer msb_pos;
  integer i;
  integer found;

  always @* begin
    sign_a    = a[15];
    sign_b    = b[15];
    sign_r    = sign_a ^ sign_b;
    exp_a     = a[14:10];
    exp_b     = b[14:10];
    frac_a    = a[9:0];
    frac_b    = b[9:0];
    mant_a    = 11'd0;
    mant_b    = 11'd0;
    prod      = 22'd0;
    mant_pre  = 11'd0;
    mant_round= 11'd0;
    sub_pre   = 32'd0;
    sub_round = 32'd0;
    guard_bit = 1'b0;
    sticky_bit= 1'b0;
    lsb_bit   = 1'b0;
    ea_eff    = 0;
    eb_eff    = 0;
    exp_norm  = 0;
    shift_amt = 0;
    msb_pos   = 0;
    found     = 0;
    result    = 16'h0000;

    if (((exp_a == 5'h1F) && (frac_a != 10'd0)) ||
        ((exp_b == 5'h1F) && (frac_b != 10'd0))) begin
      result = FP16_QNAN;
    end else if (((exp_a == 5'h1F) && (frac_a == 10'd0) && (exp_b == 5'd0) && (frac_b == 10'd0)) ||
                 ((exp_b == 5'h1F) && (frac_b == 10'd0) && (exp_a == 5'd0) && (frac_a == 10'd0))) begin
      result = FP16_QNAN;
    end else if ((exp_a == 5'h1F) && (frac_a == 10'd0)) begin
      result = {sign_r, 5'h1F, 10'd0};
    end else if ((exp_b == 5'h1F) && (frac_b == 10'd0)) begin
      result = {sign_r, 5'h1F, 10'd0};
    end else if (((exp_a == 5'd0) && (frac_a == 10'd0)) ||
                 ((exp_b == 5'd0) && (frac_b == 10'd0))) begin
      result = {sign_r, 15'd0};
    end else begin
      if (exp_a == 5'd0) begin
        mant_a = {1'b0, frac_a};
        ea_eff = -14;
      end else begin
        mant_a = {1'b1, frac_a};
        ea_eff = exp_a;
        ea_eff = ea_eff - 15;
      end

      if (exp_b == 5'd0) begin
        mant_b = {1'b0, frac_b};
        eb_eff = -14;
      end else begin
        mant_b = {1'b1, frac_b};
        eb_eff = exp_b;
        eb_eff = eb_eff - 15;
      end

      prod = mant_a * mant_b;

      msb_pos = 0;
      found   = 0;
      for (i = 21; i >= 0; i = i - 1) begin
        if ((found == 0) && (prod[i] == 1'b1)) begin
          msb_pos = i;
          found   = 1;
        end
      end

      exp_norm = ea_eff + eb_eff + msb_pos - 20;

      if (exp_norm > 15) begin
        result = {sign_r, 5'h1F, 10'd0};
      end else if (exp_norm >= -14) begin
        shift_amt = msb_pos - 10;

        if (shift_amt > 0) begin
          mant_pre   = prod >> shift_amt;
          guard_bit  = prod[shift_amt - 1];
          sticky_bit = 1'b0;
          if (shift_amt > 1) begin
            for (i = 0; i < (shift_amt - 1); i = i + 1) begin
              if (prod[i] == 1'b1)
                sticky_bit = 1'b1;
            end
          end
          lsb_bit = mant_pre[0];
          if (guard_bit && (sticky_bit || lsb_bit))
            mant_round = mant_pre + 11'd1;
          else
            mant_round = mant_pre;
        end else if (shift_amt == 0) begin
          mant_pre   = prod[10:0];
          mant_round = mant_pre;
        end else begin
          mant_pre   = prod << (-shift_amt);
          mant_round = mant_pre;
        end

        if (mant_round == 11'd2048) begin
          mant_round = 11'd1024;
          exp_norm   = exp_norm + 1;
        end

        if (exp_norm > 15) begin
          result = {sign_r, 5'h1F, 10'd0};
        end else begin
          result = {sign_r, exp_norm + 15, mant_round[9:0]};
        end
      end else begin
        shift_amt = -(ea_eff + eb_eff + 4);

        if (shift_amt > 0) begin
          if (shift_amt >= 32) begin
            sub_pre = 32'd0;
          end else begin
            sub_pre = prod >> shift_amt;
          end

          if ((shift_amt - 1) >= 0 && (shift_amt - 1) <= 21)
            guard_bit = prod[shift_amt - 1];
          else
            guard_bit = 1'b0;

          sticky_bit = 1'b0;
          if (shift_amt > 1) begin
            for (i = 0; i < 22; i = i + 1) begin
              if ((i < (shift_amt - 1)) && (prod[i] == 1'b1))
                sticky_bit = 1'b1;
            end
          end

          lsb_bit = sub_pre[0];
          if (guard_bit && (sticky_bit || lsb_bit))
            sub_round = sub_pre + 32'd1;
          else
            sub_round = sub_pre;
        end else if (shift_amt == 0) begin
          sub_pre   = prod;
          sub_round = sub_pre;
        end else begin
          sub_pre   = prod << (-shift_amt);
          sub_round = sub_pre;
        end

        if (sub_round >= 32'd1024) begin
          result = {sign_r, 5'b00001, 10'd0};
        end else if (sub_round == 32'd0) begin
          result = {sign_r, 15'd0};
        end else begin
          result = {sign_r, 5'd0, sub_round[9:0]};
        end
      end
    end
  end

endmodule
