module fp16_multiplier(
  a,
  b,
  result
);

  input  [15:0] a;
  input  [15:0] b;
  output [15:0] result;
  reg    [15:0] result;

  reg        sign_a;
  reg        sign_b;
  reg        sign_r;
  reg [4:0]  exp_a;
  reg [4:0]  exp_b;
  reg [9:0]  frac_a;
  reg [9:0]  frac_b;
  reg [10:0] mant_a;
  reg [10:0] mant_b;
  reg [21:0] prod;
  reg [10:0] mant_round;
  reg [63:0] sub_round;
  reg [4:0]  exp_field;
  reg        guard_bit;
  reg        sticky_bit;

  integer exp_a_eff;
  integer exp_b_eff;
  integer exp_sum;
  integer exp_norm;
  integer msb_pos;
  integer shift_amt;
  integer i;
  integer found;

  always @* begin
    sign_a     = a[15];
    sign_b     = b[15];
    sign_r     = sign_a ^ sign_b;
    exp_a      = a[14:10];
    exp_b      = b[14:10];
    frac_a     = a[9:0];
    frac_b     = b[9:0];
    mant_a     = 11'd0;
    mant_b     = 11'd0;
    prod       = 22'd0;
    mant_round = 11'd0;
    sub_round  = 64'd0;
    exp_field  = 5'd0;
    guard_bit  = 1'b0;
    sticky_bit = 1'b0;
    exp_a_eff  = 0;
    exp_b_eff  = 0;
    exp_sum    = 0;
    exp_norm   = 0;
    msb_pos    = 0;
    shift_amt  = 0;
    found      = 0;
    result     = 16'h0000;

    if ((exp_a == 5'h1F && frac_a != 10'd0) ||
        (exp_b == 5'h1F && frac_b != 10'd0)) begin
      result = 16'h7E00;
    end else if (((exp_a == 5'h1F) && (frac_a == 10'd0) && (exp_b == 5'd0) && (frac_b == 10'd0)) ||
                 ((exp_b == 5'h1F) && (frac_b == 10'd0) && (exp_a == 5'd0) && (frac_a == 10'd0))) begin
      result = 16'h7E00;
    end else if ((exp_a == 5'h1F) && (frac_a == 10'd0)) begin
      result = {sign_r, 5'h1F, 10'd0};
    end else if ((exp_b == 5'h1F) && (frac_b == 10'd0)) begin
      result = {sign_r, 5'h1F, 10'd0};
    end else if (((exp_a == 5'd0) && (frac_a == 10'd0)) ||
                 ((exp_b == 5'd0) && (frac_b == 10'd0))) begin
      result = {sign_r, 15'd0};
    end else begin
      mant_a    = (exp_a == 5'd0) ? {1'b0, frac_a} : {1'b1, frac_a};
      mant_b    = (exp_b == 5'd0) ? {1'b0, frac_b} : {1'b1, frac_b};
      exp_a_eff = (exp_a == 5'd0) ? -14 : (exp_a - 15);
      exp_b_eff = (exp_b == 5'd0) ? -14 : (exp_b - 15);
      exp_sum   = exp_a_eff + exp_b_eff;
      prod      = mant_a * mant_b;

      for (i = 21; i >= 0; i = i - 1) begin
        if ((found == 0) && prod[i]) begin
          msb_pos = i;
          found   = 1;
        end
      end

      exp_norm = exp_sum + msb_pos - 20;

      if (exp_norm > 15) begin
        result = {sign_r, 5'h1F, 10'd0};
      end else if (exp_norm >= -14) begin
        shift_amt = msb_pos - 10;

        if (shift_amt > 0) begin
          mant_round = prod >> shift_amt;
          guard_bit  = prod[shift_amt - 1];
          sticky_bit = 1'b0;
          for (i = 0; i < shift_amt - 1; i = i + 1) begin
            if (prod[i])
              sticky_bit = 1'b1;
          end
        end else begin
          mant_round = prod << (-shift_amt);
          guard_bit  = 1'b0;
          sticky_bit = 1'b0;
        end

        if (guard_bit && (sticky_bit || mant_round[0]))
          mant_round = mant_round + 11'd1;

        if ({1'b0, mant_round} == 12'd2048) begin
          mant_round = 11'd1024;
          exp_norm   = exp_norm + 1;
        end

        if (exp_norm > 15) begin
          result = {sign_r, 5'h1F, 10'd0};
        end else begin
          exp_field = exp_norm + 15;
          result    = {sign_r, exp_field, mant_round[9:0]};
        end
      end else begin
        shift_amt = -(exp_sum + 4);

        if (shift_amt > 0) begin
          if (shift_amt >= 64)
            sub_round = 64'd0;
          else
            sub_round = prod >> shift_amt;

          if ((shift_amt - 1) >= 0 && (shift_amt - 1) <= 21)
            guard_bit = prod[shift_amt - 1];
          else
            guard_bit = 1'b0;

          sticky_bit = 1'b0;
          if (shift_amt > 1) begin
            if ((shift_amt - 2) >= 21) begin
              if (prod != 22'd0)
                sticky_bit = 1'b1;
            end else begin
              for (i = 0; i < shift_amt - 1; i = i + 1) begin
                if (prod[i])
                  sticky_bit = 1'b1;
              end
            end
          end
        end else begin
          sub_round  = prod << (-shift_amt);
          guard_bit  = 1'b0;
          sticky_bit = 1'b0;
        end

        if (guard_bit && (sticky_bit || sub_round[0]))
          sub_round = sub_round + 64'd1;

        if (sub_round >= 64'd1024)
          result = {sign_r, 5'd1, 10'd0};
        else if (sub_round == 64'd0)
          result = {sign_r, 15'd0};
        else
          result = {sign_r, 5'd0, sub_round[9:0]};
      end
    end
  end

endmodule
