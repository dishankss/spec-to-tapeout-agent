module dot_product #(
    parameter N = 8,
    parameter WIDTH = 8
) (
    input clk,
    input rst,
    input signed [N*WIDTH-1:0] A,
    input signed [N*WIDTH-1:0] B,
    output reg signed [2*WIDTH+3:0] dot_out,
    output reg valid
);

    reg signed [2*WIDTH-1:0] mult_pipe [0:N-1];
    reg [1:0] state;
    reg signed [2*WIDTH+3:0] sum_accum;
    integer i;

    function signed [WIDTH-1:0] get_elem;
        input [N*WIDTH-1:0] vec;
        input integer idx;
        begin
            get_elem = vec[idx*WIDTH +: WIDTH];
        end
    endfunction

    always @(posedge clk) begin
        if (rst) begin
            dot_out <= 0;
            valid <= 0;
            state <= 0;
            for (i = 0; i < N; i = i + 1) begin
                mult_pipe[i] <= 0;
            end
        end else begin
            case (state)
                0: begin
                    valid <= 0;
                    for (i = 0; i < N; i = i + 1) begin
                        mult_pipe[i] <= get_elem(A, i) * get_elem(B, i);
                    end
                    state <= 1;
                end

                1: begin
                    sum_accum = 0;
                    for (i = 0; i < N; i = i + 1) begin
                        sum_accum = sum_accum + mult_pipe[i];
                    end
                    dot_out <= sum_accum;
                    valid <= 1;
                    state <= 2;
                end

                default: begin
                    valid <= 0;
                    state <= 2;
                end
            endcase
        end
    end

endmodule
