module dot_product #(
    parameter N = 8,
    parameter WIDTH = 8
) (
    input clk,
    input rst,
    input signed [N*WIDTH-1:0] A,
    input signed [N*WIDTH-1:0] B,
    output reg signed [2*WIDTH+3:0] dot_out,
    output reg valid
);

    reg signed [2*WIDTH-1:0] mult_pipe [0:N-1];
    reg [1:0] valid_pipe;
    reg signed [2*WIDTH+3:0] sum_accum;

    integer i;

    function signed [WIDTH-1:0] get_elem;
        input signed [N*WIDTH-1:0] vec;
        input integer idx;
        begin
            get_elem = vec[idx*WIDTH +: WIDTH];
        end
    endfunction

    always @(posedge clk) begin
        if (rst) begin
            dot_out <= 0;
            valid <= 0;
            valid_pipe <= 0;
            for (i = 0; i < N; i = i + 1) begin
                mult_pipe[i] <= 0;
            end
        end else begin
            sum_accum = 0;
            for (i = 0; i < N; i = i + 1) begin
                sum_accum = sum_accum + mult_pipe[i];
            end

            dot_out <= sum_accum;
            valid_pipe <= {valid_pipe[0], 1'b1};
            valid <= valid_pipe[1];

            for (i = 0; i < N; i = i + 1) begin
                mult_pipe[i] <= get_elem(A, i) * get_elem(B, i);
            end
        end
    end

endmodule
