module seq_detector_0011(
    input clk,
    input reset,
    input data_in,
    output reg detected
);

    reg [1:0] state;
    reg [1:0] next_state;
    reg next_detected;

    parameter S0 = 2'b00;
    parameter S1 = 2'b01;
    parameter S2 = 2'b10;
    parameter S3 = 2'b11;

    always @(posedge clk) begin
        if (reset) begin
            state <= S0;
            detected <= 1'b0;
        end else begin
            state <= next_state;
            detected <= next_detected;
        end
    end

    always @(state or data_in) begin
        next_state = state;
        next_detected = 1'b0;

        case (state)
            S0: begin
                if (data_in == 1'b0)
                    next_state = S1;
                else
                    next_state = S0;
            end

            S1: begin
                if (data_in == 1'b0)
                    next_state = S2;
                else
                    next_state = S0;
            end

            S2: begin
                if (data_in == 1'b1)
                    next_state = S3;
                else
                    next_state = S2;
            end

            S3: begin
                if (data_in == 1'b1) begin
                    next_state = S0;
                    next_detected = 1'b1;
                end else begin
                    next_state = S1;
                end
            end

            default: begin
                next_state = S0;
                next_detected = 1'b0;
            end
        endcase
    end

endmodule
