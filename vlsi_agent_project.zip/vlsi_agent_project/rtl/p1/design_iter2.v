module seq_detector_0011(
    input clk,
    input reset,
    input data_in,
    output reg detected
);

reg [2:0] state;
reg [2:0] next_state;

parameter S0 = 3'b000;
parameter S1 = 3'b001;
parameter S2 = 3'b010;
parameter S3 = 3'b011;
parameter S4 = 3'b100;

always @(*) begin
    case (state)
        S0: begin
            if (data_in == 1'b0)
                next_state = S1;
            else
                next_state = S0;
        end
        S1: begin
            if (data_in == 1'b0)
                next_state = S2;
            else
                next_state = S0;
        end
        S2: begin
            if (data_in == 1'b1)
                next_state = S3;
            else
                next_state = S2;
        end
        S3: begin
            if (data_in == 1'b1)
                next_state = S4;
            else
                next_state = S1;
        end
        S4: begin
            if (data_in == 1'b0)
                next_state = S1;
            else
                next_state = S0;
        end
        default: begin
            next_state = S0;
        end
    endcase
end

always @(posedge clk) begin
    if (reset) begin
        state <= S0;
        detected <= 1'b0;
    end else begin
        state <= next_state;
        if (state == S4)
            detected <= 1'b1;
        else
            detected <= 1'b0;
    end
end

endmodule
