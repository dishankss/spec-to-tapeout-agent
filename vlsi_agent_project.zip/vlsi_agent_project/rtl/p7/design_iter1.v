module exp_fixed_point #(
  parameter WIDTH = 8
) (
  input               clk,
  input               rst,
  input               enable,
  input  [WIDTH-1:0]  x_in,
  output reg [2*WIDTH-1:0] exp_out
);

  parameter FRAC = WIDTH - 1;

  reg  [WIDTH-1:0]     x_s1;
  reg  [2*WIDTH-1:0]   x2_s1;
  reg  [3*WIDTH-1:0]   x3_s1;

  wire [2*WIDTH-1:0]   x2_calc;
  wire [3*WIDTH-1:0]   x3_calc;

  wire [2*WIDTH-1:0]   term1_w;
  wire [2*WIDTH-1:0]   term2_w;
  wire [2*WIDTH-1:0]   term3_w;
  wire [3*WIDTH-1:0]   term4_shift_w;
  wire [3*WIDTH-1:0]   term4_full_w;
  wire [2*WIDTH-1:0]   term4_w;
  wire [2*WIDTH:0]     sum_w;

  assign x2_calc = x_in * x_in;
  assign x3_calc = x2_calc * x_in;

  assign term1_w      = ({ {(2*WIDTH-1){1'b0}}, 1'b1 } << FRAC);
  assign term2_w      = { {WIDTH{1'b0}}, x_s1 };
  assign term3_w      = x2_s1 >> WIDTH;
  assign term4_shift_w = x3_s1 >> (2*FRAC);
  assign term4_full_w = term4_shift_w / 6;
  assign term4_w      = term4_full_w[2*WIDTH-1:0];

  assign sum_w = {1'b0, term1_w} +
                 {1'b0, term2_w} +
                 {1'b0, term3_w} +
                 {1'b0, term4_w};

  always @(posedge clk) begin
    if (rst) begin
      x_s1    <= {WIDTH{1'b0}};
      x2_s1   <= {(2*WIDTH){1'b0}};
      x3_s1   <= {(3*WIDTH){1'b0}};
      exp_out <= {(2*WIDTH){1'b0}};
    end else if (enable) begin
      x_s1    <= x_in;
      x2_s1   <= x2_calc;
      x3_s1   <= x3_calc;
      exp_out <= sum_w[2*WIDTH-1:0];
    end
  end

endmodule
