module exp_fixed_point #(
  parameter WIDTH = 8
) (
  input clk,
  input rst,
  input enable,
  input [WIDTH-1:0] x_in,
  output reg [2*WIDTH-1:0] exp_out
);

  parameter FRAC = WIDTH - 1;

  reg [WIDTH-1:0] x_s1;
  reg [2*WIDTH-1:0] x2_s1;
  reg [3*WIDTH-1:0] x3_s1;

  wire [2*WIDTH-1:0] x2_calc;
  wire [3*WIDTH-1:0] x3_calc;

  wire [2*WIDTH-1:0] term_const;
  wire [2*WIDTH-1:0] term_x;
  wire [2*WIDTH-1:0] term_x2;
  wire [2*WIDTH-1:0] term_x3;
  wire [2*WIDTH:0] sum_terms;

  assign x2_calc = x_in * x_in;
  assign x3_calc = x2_calc * x_in;

  assign term_const = {{(2*WIDTH-1){1'b0}}, 1'b1} << FRAC;
  assign term_x     = {{WIDTH{1'b0}}, x_s1};
  assign term_x2    = x2_s1 >> (FRAC + 1);
  assign term_x3    = (x3_s1 >> (2*FRAC)) / 6;

  assign sum_terms  = {1'b0, term_const} +
                      {1'b0, term_x} +
                      {1'b0, term_x2} +
                      {1'b0, term_x3};

  always @(posedge clk) begin
    if (rst) begin
      x_s1    <= {WIDTH{1'b0}};
      x2_s1   <= {(2*WIDTH){1'b0}};
      x3_s1   <= {(3*WIDTH){1'b0}};
      exp_out <= {(2*WIDTH){1'b0}};
    end else if (enable) begin
      x_s1    <= x_in;
      x2_s1   <= x2_calc;
      x3_s1   <= x3_calc;
      exp_out <= sum_terms[2*WIDTH-1:0];
    end
  end

endmodule
